def statistical_operations(data_list):
    ''' (list) -> tuple
    Program returns mean and standard deviation
    '''
    m = mean(data_list)
    print('brace yourself, I\'m counting!')
    
    return (m, stdev(data_list, m))

def mean(data):
    '''(list) -> float
    Returns mean from list of floats
    '''
    return sum(data)/len(data)

def stdev(data, avg):
    '''(list, float) -> float
    Calculates corrected standard deviatin of list of numbers
    '''
    return ( sum([ (x - avg)**2 for x in data ])/(len(data)-1) ) **0.5
'''    
L = [3,1,5,6,2]
print(statistical_operations(L))
'''
if __name__ == '__main__':
    L = [3,1,5,6,2]
    print(statistical_operations(L))




