"""
#importowanie wlasnego modulu
import avg_dev as avg

def arrayToAvg(array):
    ''' (list) -> list'''
    AVG = []
    for item in array:
        AVG.append(avg.mean(item))

    print(AVG)
"""

#to samo z modulem wbudowanym do statystyki
import statistics as stat

def arrayToAvg(array):
    ''' (list) -> list'''
    AVG = []
    for item in array:
        AVG.append(stat.mean(item))
    print(AVG)
